module.exports = {
  root: true,
  parser: 'babel-eslint',
  extends: 'standard',
  'rules': {
    'arrow-parens': 0
  }
}

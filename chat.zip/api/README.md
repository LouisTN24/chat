# Node API Skeleton
> Pavel Koch

## Installation
Clone the repo to desired location, rename, change package.json specs and run `npm install`.

## Commands
`npm run build`

Builds project for production.

`npm run watch`

Starts local server for development.

`npm run test`

Runs Mocha tests.
